-- New Datatype "Call"for Phone numbers:
insert into adempiere.ad_reference values (41,0,0,'Y','2009-12-22 23:22:12',100,'2009-12-22 23:33:03',100,'Call','Call',NULL,'D',NULL,'D','N');
update adempiere.ad_column set ad_reference_id=41 where name like '%Phone' or name like '%ISDN%';
